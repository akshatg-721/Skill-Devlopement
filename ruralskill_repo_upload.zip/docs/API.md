API (v1)

Base URL: /api/v1

Health
- GET /health

Courses
- GET /courses/search?query&is_free&level&language&min_price_inr&max_price_inr&max_duration_hours
  Response example:
  {
    "status": 200,
    "data": [
      {
        "id": "yt-1",
        "title": "C++ Fundamentals",
        "platform": "YouTube",
        "url": "https://youtube.com/example",
        "price_inr": 0,
        "level": "Beginner",
        "language": "English",
        "duration_hours": 8,
        "is_free": true
      }
    ]
  }

Recommendations
- GET /recommendations/learning-paths?skill

Assessments
- GET /assessments/quiz?module_id
- POST /assessments/submit { quiz_id, selected_indices }
  Response example:
  { "score_percent": 100.0, "weak_topics": [], "recommendations": ["advance-to-next-module"] }

Progress
- POST /progress/event { user_id, course_id, module_id, action, value }
- GET /progress/summary?user_id&course_id

Jobs
- GET /jobs/search?skill&region
  Response example:
  [ { "id": "lnk-1", "title": "C++ Intern", "company": "Local Co", "location": "Remote", "url": "https://www.linkedin.com/jobs/" } ]


