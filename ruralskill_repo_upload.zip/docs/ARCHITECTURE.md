Architecture

High-Level
- Frontend: React + Tailwind CSS
- Backend: FastAPI (Python)
- DB: PostgreSQL (primary), Redis (caching/queues)
- Storage: S3-compatible for assets
- Message Queue: Redis Streams or RabbitMQ (future)

Services
1) Course Aggregation Service
   - Integrates YouTube, Khan Academy, FreeCodeCamp, Coursera, Udemy
   - Normalizes metadata (price in INR, level, duration, language)
2) Recommendation Service
   - Cold-start via interests and local job demand
   - Ongoing personalization via progress, quiz performance
3) Assessment Service
   - Auto-generates adaptive quizzes and diagnostics
4) Progress & Mastery Service
   - Tracks time, completion, mastery; issues badges/certificates
5) Jobs Integration Service
   - Maps skills to jobs (LinkedIn, govt portals)

APIs
- REST JSON over HTTPS
- Auth: email/OTP initially; OAuth later
- Versioning: /api/v1

Data Model (initial sketch)
- User, Skill, Course, Enrollment, ProgressEvent, Quiz, QuizAttempt, Recommendation, JobPosting

Non-Functional
- Accessibility: multilingual, low-data mode, offline support (PWA)
- Observability: structured logs, metrics, tracing
- Security: input validation, rate limiting, secrets management


