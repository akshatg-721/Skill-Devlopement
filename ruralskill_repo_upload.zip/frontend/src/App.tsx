import React, { useEffect, useState } from 'react'

type Course = {
	id: string
	title: string
	platform: string
	url: string
	price_inr?: number
	level?: string
	language?: string
	duration_hours?: number
	is_free: boolean
}

const apiBase = import.meta.env.VITE_API_BASE || 'http://localhost:8000/api/v1'

export default function App() {
	const [query, setQuery] = useState('C++')
	const [isFree, setIsFree] = useState<string>('')
	const [language, setLanguage] = useState('')
	const [courses, setCourses] = useState<Course[]>([])

	useEffect(() => {
		const params = new URLSearchParams()
		if (query) params.set('query', query)
		if (isFree) params.set('is_free', isFree)
		if (language) params.set('language', language)
		fetch(`${apiBase}/courses/search?${params.toString()}`)
			.then(r => r.json())
			.then(setCourses)
			.catch(() => setCourses([]))
	}, [query, isFree, language])

	return (
		<div className="min-h-screen p-4">
			<h1 className="text-2xl font-bold mb-4">Rural Skill Development</h1>
			<div className="grid gap-2 sm:grid-cols-3 mb-4">
				<input className="border p-2" placeholder="Search skill (e.g., C++)" value={query} onChange={e => setQuery(e.target.value)} />
				<select className="border p-2" value={isFree} onChange={e => setIsFree(e.target.value)}>
					<option value="">All</option>
					<option value="true">Free</option>
					<option value="false">Paid</option>
				</select>
				<select className="border p-2" value={language} onChange={e => setLanguage(e.target.value)}>
					<option value="">Any language</option>
					<option value="English">English</option>
					<option value="Hindi">Hindi</option>
				</select>
			</div>
			<ul className="space-y-2">
				{courses.map(c => (
					<li key={c.id} className="border p-3 rounded">
						<div className="font-semibold">{c.title}</div>
						<div className="text-sm">{c.platform} • {c.language ?? '—'} • {c.level ?? '—'}</div>
						<a className="text-blue-600 text-sm" href={c.url} target="_blank" rel="noreferrer">Open</a>
					</li>
				))}
			</ul>
		</div>
	)
}


