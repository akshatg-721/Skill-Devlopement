from fastapi import APIRouter

from .routers import courses, recommendations, assessments, progress, jobs


api_router = APIRouter()

api_router.include_router(courses.router, prefix="/courses", tags=["courses"])
api_router.include_router(recommendations.router, prefix="/recommendations", tags=["recommendations"])
api_router.include_router(assessments.router, prefix="/assessments", tags=["assessments"])
api_router.include_router(progress.router, prefix="/progress", tags=["progress"])
api_router.include_router(jobs.router, prefix="/jobs", tags=["jobs"])


