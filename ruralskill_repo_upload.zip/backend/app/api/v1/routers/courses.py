from typing import List, Optional
from fastapi import APIRouter, Query
from pydantic import BaseModel
from ....schemas import Course as CourseSchema


class Course(BaseModel):
    id: str
    title: str
    platform: str
    url: str
    price_inr: Optional[float] = None
    level: Optional[str] = None
    language: Optional[str] = None
    duration_hours: Optional[float] = None
    is_free: bool = False


router = APIRouter()


@router.get("/search", response_model=List[Course])
def search_courses(
	query: str = Query(""),
	is_free: Optional[bool] = None,
	level: Optional[str] = None,
	language: Optional[str] = None,
	min_price_inr: Optional[float] = None,
	max_price_inr: Optional[float] = None,
	max_duration_hours: Optional[float] = None,
) -> List[Course]:
	# Placeholder: return mocked courses until aggregation is implemented
    mock: List[CourseSchema] = [
        CourseSchema(
			id="yt-1",
			title="C++ Fundamentals",
			platform="YouTube",
			url="https://youtube.com/example",
			price_inr=0,
			level="Beginner",
			language="English",
			duration_hours=8,
			is_free=True,
		)
	]
    return [Course(**c.model_dump()) for c in mock]


