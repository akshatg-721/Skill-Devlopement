from typing import List
from fastapi import APIRouter
from pydantic import BaseModel


class Recommendation(BaseModel):
	path_id: str
	label: str
	courses: List[str]


router = APIRouter()


@router.get("/learning-paths", response_model=List[Recommendation])
def get_learning_paths(skill: str) -> List[Recommendation]:
	return [
		Recommendation(path_id="cpp-beginner", label="C++ Beginner Path", courses=["yt-1", "fc-1"])
	]


