from typing import List
from fastapi import APIRouter
from pydantic import BaseModel


class JobPosting(BaseModel):
	id: str
	title: str
	company: str
	location: str
	url: str


router = APIRouter()


@router.get("/search", response_model=List[JobPosting])
def search_jobs(skill: str, region: str | None = None) -> List[JobPosting]:
	return [
		JobPosting(
			id="lnk-1",
			title=f"{skill} Intern",
			company="Local Co",
			location=region or "Remote",
			url="https://www.linkedin.com/jobs/",
		)
	]


