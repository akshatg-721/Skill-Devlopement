from typing import List
from fastapi import APIRouter
from pydantic import BaseModel


class QuizQuestion(BaseModel):
	id: str
	prompt: str
	options: List[str]
	answer_index: int


class Quiz(BaseModel):
	id: str
	module_id: str
	questions: List[QuizQuestion]


class QuizSubmission(BaseModel):
	quiz_id: str
	selected_indices: List[int]


class QuizResult(BaseModel):
	score_percent: float
	weak_topics: List[str]
	recommendations: List[str]


router = APIRouter()


@router.get("/quiz", response_model=Quiz)
def generate_quiz(module_id: str) -> Quiz:
	return Quiz(
		id="quiz-1",
		module_id=module_id,
		questions=[
			QuizQuestion(id="q1", prompt="What is 2+2?", options=["3", "4", "5", "6"], answer_index=1)
		],
	)


@router.post("/submit", response_model=QuizResult)
def submit_quiz(submission: QuizSubmission) -> QuizResult:
	# Placeholder logic
	return QuizResult(score_percent=100.0, weak_topics=[], recommendations=["advance-to-next-module"])


