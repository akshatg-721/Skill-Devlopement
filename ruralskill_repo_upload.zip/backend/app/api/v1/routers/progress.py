from typing import List
from fastapi import APIRouter
from pydantic import BaseModel


class ProgressEvent(BaseModel):
	user_id: str
	course_id: str
	module_id: str
	action: str  # started, completed, time_spent
	value: float | None = None  # seconds for time_spent


class ProgressSummary(BaseModel):
	completion_percent: float
	time_spent_seconds: float


router = APIRouter()


@router.post("/event")
def record_event(event: ProgressEvent) -> dict:
	return {"status": "recorded"}


@router.get("/summary", response_model=ProgressSummary)
def get_summary(user_id: str, course_id: str) -> ProgressSummary:
	return ProgressSummary(completion_percent=25.0, time_spent_seconds=3600)


