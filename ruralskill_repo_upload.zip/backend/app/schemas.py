from __future__ import annotations

from typing import List, Optional
from pydantic import BaseModel, EmailStr, Field


class User(BaseModel):
	id: str
	name: str
	email: Optional[EmailStr] = None
	language_preference: Optional[str] = Field(default="English")
	region: Optional[str] = None


class Skill(BaseModel):
	id: str
	name: str
	category: Optional[str] = None
	description: Optional[str] = None


class Course(BaseModel):
	id: str
	title: str
	platform: str
	url: str
	is_free: bool
	price_inr: Optional[float] = None
	level: Optional[str] = None  # Beginner, Intermediate, Advanced
	language: Optional[str] = None
	duration_hours: Optional[float] = None
	skills: List[str] = []  # list of Skill ids or names


class Enrollment(BaseModel):
	id: str
	user_id: str
	course_id: str
	status: str = Field(default="in_progress")  # in_progress, completed, dropped
	progress_percent: float = 0.0
	seconds_spent: float = 0.0


class ProgressEvent(BaseModel):
	id: Optional[str] = None
	user_id: str
	course_id: str
	module_id: str
	action: str  # started, completed, time_spent
	value: Optional[float] = None  # seconds for time_spent
	timestamp_iso: Optional[str] = None


class QuizQuestion(BaseModel):
	id: str
	prompt: str
	options: List[str]
	answer_index: int
	topic: Optional[str] = None


class Quiz(BaseModel):
	id: str
	module_id: str
	questions: List[QuizQuestion]


class QuizSubmission(BaseModel):
	quiz_id: str
	selected_indices: List[int]


class QuizResult(BaseModel):
	score_percent: float
	weak_topics: List[str]
	recommendations: List[str]


class LearningPath(BaseModel):
	path_id: str
	label: str
	courses: List[str]


class JobPosting(BaseModel):
	id: str
	title: str
	company: str
	location: str
	url: str
	related_skills: List[str] = []


