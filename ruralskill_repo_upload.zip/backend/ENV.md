Backend Environment Variables

Copy these into a local .env file at backend/.env

- APP_ENV: development | production
- DATABASE_URL: e.g. postgresql+psycopg2://user:password@localhost:5432/ruralskill
- REDIS_URL: e.g. redis://localhost:6379/0
- YOUTUBE_API_KEY: API key for YouTube Data API v3
- LINKEDIN_API_KEY: API key/token for jobs integration (placeholder)


